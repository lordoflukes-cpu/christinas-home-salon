# Gold Trading Kit — Complete Export

Two folders, one package:

## claude-trading-kit/
The **portable, drop-in layer**: 42 skills · 19 agents · 12 workflows · 5 commands/hooks ·
29 connectors · full docs · external-plugin companion layer.

Copy `claude-trading-kit/skills/ agents/ commands/ hooks/` into any project's `.claude/` and
it works immediately (pure-reasoning skills). See `claude-trading-kit/docs/copy-and-export.md`
for the 3 usage modes.

## trading-suite/
The **runnable engine**: 6 Claude Code marketplace plugins backed by the vendored gold-bot
engine. Requires Python 3.11+ and a venv.

```
cd trading-suite && python -m venv .venv && .venv/bin/pip install -r requirements.txt
cd trading-suite && .venv/bin/pytest plugins/trading-research -q   # 11 tests pass
```

See `trading-suite/README.md` for full setup.

---
Built: 2026-06-28
